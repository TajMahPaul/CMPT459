# CMPT459 Assignment #2

## Steps to Run

```bash
# create data cude using buc.py
python3 buc.py

# run code to generate pairs
python3 dem.py

# output will be in pair.csv, cube will be in dem.csv
```
